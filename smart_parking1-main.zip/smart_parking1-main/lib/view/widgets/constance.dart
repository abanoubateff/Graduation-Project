import 'package:flutter/material.dart';
//colors app
const primaryColor = Color(0xff43a5c8 );

const secondColor = Color(0xFFe0f0f6);

//all string in app
class TextString{
static String createAccountString='CREATE AN ACCOUNT';
static String smartParkingString= "Smart Parking 🚗";
static String signInString='LOGIN IN';
static String nameString='Name';
static String emailString='Email';
static String phoneNumberString='Phone Number';
static String passwordString='Password';
static String addNewCard='Add New Card';
static String yourCards='Your Cards';



}